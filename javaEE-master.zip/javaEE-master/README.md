# javaEE
Sample app JavaEE: JSP, EJB, Servlet, JQuery Json, Bootstrap
